<?php
include_once "../Operations/connection.php";

if (!empty($_POST)) {
    $name = $_POST['name'];
    $details = $_POST['details'];
    $category = $_POST['category'];
    $price = $_POST['price'];

    $image_file_name = $_FILES['file']['name'];
    if (!$image_file_name == "") {

        $tmp_name =  $_FILES['file']['tmp_name'];

        $location = "../images/products/";
        $uniquename = time() . "-" . rand(1000, 9999) . "-" . $image_file_name;

        $new_name = $location . $uniquename;
        if (move_uploaded_file($tmp_name, $new_name)) {
            echo "<br>uploaded";
        } else {
            $uniquename = time() . "-" . rand(1000, 9999) . "-" . $image_file_name;
            $new_name = $location . $uniquename;
            if (move_uploaded_file($tmp_name, $new_name)) {
                echo "<br>uploaded ";
            } else {
                $uniquename = '';
                echo "failed, better luck next time";
            }
        }
    }
    $sql = "INSERT INTO products(name, category, details, image, price) VALUES ('$name', '$category', '$details', '$uniquename', $price)";

    if ($conn->query($sql)) {
        header('Location: list.php');
    }
    
    
} else {
    //
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Add Product</title>
    <link href="css/styles.css" rel="stylesheet" />
    <link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet" crossorigin="anonymous" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <?php
    include "includes/navbar.php";
    ?>
    <div id="layoutSidenav">
        <?php
        include 'includes/sidebar.php';
        ?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h1 class="mt-4">Add Products</h1>
                    <ol class="breadcrumb mb-4">
                        <li class="breadcrumb-item active">Add Products</li>
                    </ol>

                    <form action="<?= $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data">

                        <div class="form-group">
                            <label for="exampleInputEmail1">Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Product Name">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Details</label>
                            <textarea name="details" class="form-control" cols="30" rows="7" placeholder="Product description"></textarea>
                        </div>

                        <div class="form-group">
                            <label for="exampleFormControlSelect1">Category</label>
                            <select name="category" class="form-control" id="exampleFormControlSelect1">
                                <?php
                                $sql = "SELECT * FROM category  ORDER BY category ASC";
                                $result = mysqli_query($conn, $sql);

                                if (mysqli_num_rows($result) > 0) {
                                    // output data of each row
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo " <option name='category' value='" . $row['category'] . "'>" . $row['category'] . "</option>";
                                    }
                                } else {
                                    echo "<option>N/A</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Price</label>
                            <input type="number" name="price" class="form-control" placeholder="Price">
                        </div>

                        <div class="form-group">
                            <label for="exampleFormControlFile1">Example file input</label>
                            <input type="file" name="file" class="form-control-file" id="exampleFormControlFile1">
                        </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>


                </div>
            </main>

            <?php
            include 'includes/navbar.php';
            ?>

        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/datatables-demo.js"></script>
</body>

</html>