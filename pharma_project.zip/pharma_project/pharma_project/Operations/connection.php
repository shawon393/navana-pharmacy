<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$db = "pharma_project";

$conn = new mysqli($dbhost, $dbuser, $dbpass,$db);
   
?>