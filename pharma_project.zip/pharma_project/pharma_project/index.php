<?php
include_once "Operations/connection.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Navana Pharma | Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css?family=Rubik:400,700|Crimson+Text:400,400i" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">


  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/style.css">

</head>

<body>

  <div class="site-wrap">


    <?php
    include 'includes/header.php';
    ?>

    <div class="site-blocks-cover" style="background-image: url('images/pd.jpg');">
      <div class="container">
        <div class="row">
          <div class="col-lg-7 mx-auto order-lg-2 align-self-center">
            <div class="site-block-cover-content text-center">
              <h2 class="sub-title">Effective Medicine, New Medicine Everyday</h2>
              <h1>Welcome To navana Pharma</h1>
              <p>
                <a href="shop.php" class="btn btn-primary px-5 py-3">Shop Now</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section">
      <div class="container">
        <div class="row align-items-stretch section-overlap">
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
            <div class="banner-wrap bg-primary h-100">
              <a href="#" class="h-100">
                <h5>Free <br> Shipping</h5>
                <p>
                  inside dhaka we provide free shipping
                  <strong>Must buy medicine price above 1000 tk</strong>
                </p>
              </a>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
            <div class="banner-wrap h-100">
              <a href="#" class="h-100">
                <h5>Season <br> Sale 15% Off</h5>
                <p>
                  "on kids diaper and cleaning materials"
                  <strong>untill december </strong>
                </p>
              </a>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
            <div class="banner-wrap bg-warning h-100">
              <a href="#" class="h-100">
                <h5>Buy <br> A Gift Card</h5>
                <p>
                  use gift card to enjoy special discount
                  <strong>can use in campaigns</strong>
                </p>
              </a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="title-section text-center col-12">
            <h2 class="text-uppercase">Popular Products</h2>
          </div>
        </div>

        <div class="row">
          <?php
          $sql = "SELECT * FROM products  ORDER BY name DESC LIMIT 6";
          $result = mysqli_query($conn, $sql);

          if (mysqli_num_rows($result) > 0) {
            // output data of each row
            while ($row = mysqli_fetch_assoc($result)) {
              echo "<div class='col-sm-6 col-lg-4 text-center item mb-4'>
                      <a href='shop-single.html'> <img src='images/products/" . $row['image'] . "'></a>
                      <h3 class='text-dark'><a href='shop-single.php?id=" . $row['id'] . "'>" . $row['name'] . "</a></h3>
                      <p class='price'>" . $row['price'] . " bdt</p>
                    </div>";
            }
          } else {
            echo "0 results";
          }
          ?>
        </div>
        <div class="row mt-5">
          <div class="col-12 text-center">
            <a href="shop.php" class="btn btn-primary px-4 py-3">View All Products</a>
          </div>
        </div>
      </div>
    </div>


    <div class="site-section bg-light">
      <div class="container">
        <div class="row">
          <div class="title-section text-center col-12">
            <h2 class="text-uppercase">New Products</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 block-3 products-wrap">
            <div class="nonloop-block-3 owl-carousel">
              <?php
              $sql = "SELECT * FROM products  ORDER BY id DESC LIMIT 4";
              $result = mysqli_query($conn, $sql);

              if (mysqli_num_rows($result) > 0) {
                // output data of each row
                while ($row = mysqli_fetch_assoc($result)) {
                  echo "<div class='text-center item mb-4'>
                          <a href='shop-single.php?id=" . $row['id'] . "'> <img src='images/products/" . $row['image'] . "' alt='Image'></a>
                          <h3 class='text-dark'><a href='shop-single.php?id=" . $row['id'] . "'>" . $row['name'] . "</a></h3>
                          <p class='price'>" . $row['price'] . " bdt</p>
                        </div>";
                }
              } else {
                echo "0 results";
              }
              ?>

            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="title-section text-center col-12">
            <h2 class="text-uppercase">Testimonials</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 block-3 products-wrap">
            <div class="nonloop-block-3 no-direction owl-carousel">

              <div class="testimony">
                <blockquote>
                  <img src="images/mostafa.jpg" alt="Image" class="img-fluid w-25 mb-4 rounded-circle">
                  <p>&ldquo;“True health care reform cannot happen in Washington. It has to happen in our kitchens, in our homes, in our communities. All health care is personal.”.&rdquo;</p>
                </blockquote>

                <p>&mdash; sm mustafa zaman</p>
              </div>

              <div class="testimony">
                <blockquote>
                  <img src="images/person_2.jpg" alt="Image" class="img-fluid w-25 mb-4 rounded-circle">
                  <p>&ldquo;I promise to devote myself to a lifetime of service to others through the profession of pharmacy. In fulfilling this vow: ... I will hold myself and my colleagues to the highest principles of our profession's moral, ethical and legal conduct. I will embrace and advocate changes that improve patient care.&rdquo;</p>
                </blockquote>

                <p>&mdash; Rebecca Morando</p>
              </div>

              <div class="testimony">
                <blockquote>
                  <img src="images/boren.jpg" alt="Image" class="img-fluid w-25 mb-4 rounded-circle">
                  <p>&ldquo; Pharmacists consistently rank as one of the most trusted professions in Canada. 93% of Canadians have a positive impression of pharmacists and believe that pharmacists play an essential or important role in Canada’s healthcare system. Most Canadians trust pharmacists to provide advice on medications (96%), management of common or minor ailments (93%), management of chronic diseases (90%), healthy lifestyle changes (90%), and vaccinations (87%&rdquo;</p>
                </blockquote>

                <p>&mdash; Lucas Gallone</p>
              </div>

              <div class="testimony">
                <blockquote>
                  <img src="images/person_4.jpg" alt="Image" class="img-fluid w-25 mb-4 rounded-circle">
                  <p>&ldquo;Everything that irritates us about others can lead us to an understanding of ourselves.&rdquo;</p>
                </blockquote>

                <p>&mdash; md tamim</p>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section bg-secondary bg-image" style="background-image: url('images/bg_2.jpg');">
      <div class="container">
        <div class="row align-items-stretch">
          <div class="col-lg-6 mb-5 mb-lg-0">
            <a href="#" class="banner-1 h-100 d-flex" style="background-image: url('images/bg_1.jpg');">
              <div class="banner-1-inner align-self-center">
                <h2>Pharma Products</h2>
                <p>we ensure the market value and the best quality medicine .and we delivery fast to
                  any place in our country
                </p>
              </div>
            </a>
          </div>
          <div class="col-lg-6 mb-5 mb-lg-0">
            <a href="#" class="banner-1 h-100 d-flex" style="background-image: url('images/bg_2.jpg');">
              <div class="banner-1-inner ml-auto  align-self-center">
                <h2>Rated by Experts</h2>
                <p>all the medicine are in good quality ,u the people can buy medicine from here easily.
                </p>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>


    <?php
    include 'includes/footer.php';
    ?>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>

</body>

</html>